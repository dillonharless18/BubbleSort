# Collection of Algorithms

## Bubble Sort
## Recursive Find Largest
## Recursive Binary Digit Finder